# NextReceipt Python SDK

Official Python SDK for integrating with NextReceipt API.

## Installation

```bash
pip install nextreceipt-sdk
```

## Quick Start

### Option 1: Simple Mode (No Mapping)

Use this when your JSON already matches NextReceipt schema:

```python
from nextreceipt_sdk import NextReceiptClient

# Initialize client
client = NextReceiptClient(
    client_id="your_client_id",
    client_secret="your_client_secret"
)

# Send receipt
result = client.send_receipt({
    "payload": {
        "sale": {
            "id": "SALE123",
            "total_amount": 150.50
        },
        "merchant": {
            "name": "My Store",
            "branch": "Main Branch"
        },
        "currency": "ILS",
        "items": [
            {
                "name": "Product 1",
                "qty": 2,
                "unit_price": 75.25,
                "line_total": 150.50
            }
        ],
        "payments": [
            {
                "method": "credit_card",
                "amount": 150.50
            }
        ]
    }
})

if result.success:
    print(f"Receipt sent! ID: {result.receipt_id}")
    print(f"View at: {result.html_url}")
else:
    print(f"Error: {result.error}")
```

### Option 2: Smart Mode (With Mapping)

Use this when you have your own JSON format and an active mapping configured:

```python
from nextreceipt_sdk import NextReceiptClient

# Initialize client
client = NextReceiptClient(
    client_id="your_client_id",
    client_secret="your_client_secret"
)

# Send receipt with automatic mapping
# SDK will:
# 1. Fetch active mapping
# 2. Transform your JSON
# 3. Send to webhook
result = client.send_receipt_with_mapping({
    "OrderID": "12345",
    "TotalPrice": 150.50,
    "StoreName": "My Store",
    "Items": [
        {
            "ProductName": "Product 1",
            "Quantity": 2,
            "Price": 75.25
        }
    ]
})

if result.success:
    print(f"Receipt sent! ID: {result.receipt_id}")
else:
    print(f"Error: {result.error}")
```

## Configuration Options

```python
from nextreceipt_sdk import NextReceiptClient, ClientOptions

options = ClientOptions(
    base_url="https://nextreceipt-api.onrender.com",  # Default
    timeout=30,                # Request timeout in seconds
    auto_retry=True,           # Auto-retry on 5xx errors
    max_retries=3,             # Maximum retry attempts
    cache_token=True,          # Cache OAuth token
    throw_on_duplicate=False,  # Don't throw exception on duplicate
    enable_logging=True        # Enable logging
)

client = NextReceiptClient(
    client_id="your_client_id",
    client_secret="your_client_secret",
    options=options
)
```

## Features

✅ **Automatic OAuth Token Management** - Caches tokens, refreshes automatically  
✅ **Auto-Retry on Failures** - Exponential backoff on 5xx errors  
✅ **Idempotency Protection** - Automatic via `sale.id`  
✅ **Mapping Support** - Automatic JSON transformation  
✅ **Type Hints** - Full type annotations  
✅ **Logging** - Built-in logging support  

## Error Handling

```python
from nextreceipt_sdk import (
    NextReceiptClient,
    AuthenticationException,
    DuplicateReceiptException,
    MappingNotFoundException,
    ValidationException
)

client = NextReceiptClient(client_id="...", client_secret="...")

try:
    result = client.send_receipt_with_mapping(my_json)
    
    if result.success:
        print(f"Success: {result.receipt_id}")
    else:
        print(f"Failed: {result.error}")
        
except AuthenticationException as e:
    print(f"Authentication failed: {e}")
except MappingNotFoundException as e:
    print(f"No active mapping found: {e}")
except ValidationException as e:
    print(f"Invalid receipt data: {e}")
```

## Requirements

- Python 3.8+
- `requests` library

## License

MIT License

