"""
Main NextReceipt SDK Client
"""

import requests
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import time

from .models import ClientOptions, ReceiptResponse, MappingInfo
from .exceptions import (
    AuthenticationException, 
    DuplicateReceiptException,
    MappingNotFoundException,
    TransformationException,
    ValidationException,
    NextReceiptException
)


class NextReceiptClient:
    """
    NextReceipt SDK Client
    
    Supports two integration modes:
    1. Simple Mode: Send receipts that already match NextReceipt schema
    2. Smart Mode: Automatically fetch mapping, transform, and send
    
    Example (Simple Mode):
        client = NextReceiptClient(client_id="...", client_secret="...")
        result = client.send_receipt({
            "payload": {
                "sale": {"id": "123", "total_amount": 150.50},
                "merchant": {"name": "My Store"},
                ...
            }
        })
    
    Example (Smart Mode with Mapping):
        client = NextReceiptClient(client_id="...", client_secret="...")
        result = client.send_receipt_with_mapping({
            "OrderID": "123",
            "TotalPrice": 150.50,
            "StoreName": "My Store"
        })
    """
    
    def __init__(
        self, 
        client_id: str, 
        client_secret: str,
        options: Optional[ClientOptions] = None
    ):
        """
        Initialize NextReceipt client
        
        Args:
            client_id: OAuth client ID
            client_secret: OAuth client secret
            options: Optional configuration options
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.options = options or ClientOptions()
        
        # Token cache
        self._access_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None
        
        # Mapping cache
        self._active_mapping: Optional[MappingInfo] = None
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        if self.options.enable_logging:
            logging.basicConfig(
                level=logging.INFO,
                format='[%(levelname)s] %(message)s'
            )
    
    def _get_oauth_token(self) -> str:
        """
        Get OAuth access token (cached if available)
        
        Returns:
            Access token string
            
        Raises:
            AuthenticationException: If authentication fails
        """
        # Return cached token if still valid
        if (self.options.cache_token and 
            self._access_token and 
            self._token_expires_at and 
            datetime.now() < self._token_expires_at):
            print("   Using cached OAuth token")
            return self._access_token
        
        # Request new token
        print("   Requesting OAuth token...")
        
        try:
            response = requests.post(
                f"{self.options.base_url}/oauth/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret
                },
                timeout=self.options.timeout
            )
            
            if response.status_code != 200:
                raise AuthenticationException(
                    f"OAuth authentication failed: {response.status_code} - {response.text}"
                )
            
            data = response.json()
            self._access_token = data["access_token"]
            
            # Cache token for 50 minutes (10 min buffer before expiry)
            expires_in = data.get("expires_in", 3600)
            self._token_expires_at = datetime.now() + timedelta(seconds=expires_in - 600)
            
            print(f"   OAuth token obtained, expires at {self._token_expires_at.strftime('%H:%M:%S')}")
            return self._access_token
            
        except requests.RequestException as e:
            raise AuthenticationException(f"Failed to obtain OAuth token: {str(e)}")
    
    def _validate_receipt(self, receipt_data: Dict[str, Any]) -> None:
        """
        Validate receipt data has required fields
        
        Args:
            receipt_data: Receipt data to validate
            
        Raises:
            ValidationException: If validation fails
        """
        # C# SDK doesn't validate payload structure, so we'll keep it minimal
        # Just check that we have some data
        if not receipt_data:
            raise ValidationException("Receipt data cannot be empty")
    
    def send_receipt(self, receipt_data: Dict[str, Any]) -> ReceiptResponse:
        """
        Send receipt (Simple Mode - no mapping)
        
        Use this when your JSON already matches NextReceipt schema.
        
        Args:
            receipt_data: Receipt in NextReceipt format with 'payload' wrapper
            
        Returns:
            ReceiptResponse with result
            
        Raises:
            ValidationException: If receipt data is invalid
            DuplicateReceiptException: If receipt with same sale.id already sent
            NextReceiptException: For other errors
            
        Example:
            result = client.send_receipt({
                "payload": {
                    "sale": {"id": "SALE123", "total_amount": 150.50},
                    "merchant": {"name": "My Store"},
                    "currency": "ILS",
                    "items": [{"name": "Item", "qty": 1, "unit_price": 150.50, "line_total": 150.50}],
                    "payments": [{"method": "credit_card", "amount": 150.50}]
                }
            })
        """
        print("📤 Sending receipt (Simple Mode)...")
        
        # Validate
        self._validate_receipt(receipt_data)
        
        # Get token
        token = self._get_oauth_token()
        
        # Send to webhook
        return self._send_to_webhook(receipt_data, token)
    
    def send_receipt_with_mapping(self, original_json: Dict[str, Any]) -> ReceiptResponse:
        """
        Send receipt with automatic mapping (Smart Mode)
        
        This method performs 3 operations automatically:
        1. Fetch active mapping from API
        2. Transform your JSON to NextReceipt format
        3. Send to webhook
        
        Args:
            original_json: Your original JSON format (will be transformed)
            
        Returns:
            ReceiptResponse with result
            
        Raises:
            MappingNotFoundException: If no active mapping found
            TransformationException: If transformation fails
            DuplicateReceiptException: If receipt already sent
            NextReceiptException: For other errors
            
        Example:
            result = client.send_receipt_with_mapping({
                "OrderID": "12345",
                "TotalPrice": 150.50,
                "StoreName": "My Store",
                "Items": [{"Name": "Item", "Qty": 1, "Price": 150.50}]
            })
        """
        print("📤 Sending receipt (Smart Mode with Mapping)...")
        
        # Step 1: Get OAuth token
        token = self._get_oauth_token()
        
        # Step 2: Get active mapping
        print("   Step 1/3: Fetching active mapping...")
        mapping = self._get_active_mapping(token)
        
        # Step 3: Transform JSON
        print("   Step 2/3: Transforming JSON...")
        transformed = self._transform_json(original_json, mapping.mapping_id, token)
        
        # Debug: print transformed JSON structure and sale.id for idempotency tracing
        try:
            import json
            transformed_str = json.dumps(transformed)
            print(f"   Transformed JSON structure: {transformed_str[:200]}...")
            
            if isinstance(transformed, dict) and "sale" in transformed:
                sale_obj = transformed["sale"]
                if isinstance(sale_obj, dict) and "id" in sale_obj:
                    print(f"   Transformed sale.id: {sale_obj['id']}")
                else:
                    print("   Transformed sale.id: NOT FOUND")
                    print(f"   Sale object: {sale_obj}")
            else:
                print("   Transformed sale.id: NOT FOUND")
                print(f"   Transformed has 'sale' property: {'sale' in transformed if isinstance(transformed, dict) else False}")
                if isinstance(transformed, dict):
                    print(f"   All properties in transformed: {', '.join(transformed.keys())}")
        except Exception as ex:
            print(f"   Transformed sale.id: ERROR READING - {ex}")
        
        # Step 4: Send to webhook
        print("   Step 3/3: Sending to webhook...")
        
        # The transformed JSON already contains the payload structure (sale, merchant, items, etc.)
        # We need to wrap it in a payload envelope for the webhook
        envelope = {"payload": transformed}
        
        return self._send_to_webhook(envelope, token)
    
    def _get_active_mapping(self, token: str) -> MappingInfo:
        """
        Fetch active mapping from API
        
        Args:
            token: OAuth access token
            
        Returns:
            MappingInfo object
            
        Raises:
            MappingNotFoundException: If no active mapping found
        """
        try:
            response = requests.get(
                f"{self.options.base_url}/api/providers/field-mappings/active",
                headers={"Authorization": f"Bearer {token}"},
                timeout=self.options.timeout
            )
            
            if response.status_code == 404:
                raise MappingNotFoundException(
                    "No active mapping found. Please create and activate a mapping in the backoffice first."
                )
            
            if response.status_code != 200:
                raise NextReceiptException(
                    f"Failed to fetch mapping: {response.status_code} - {response.text}"
                )
            
            data = response.json()
            mapping = MappingInfo(
                mapping_id=data["mapping_id"],
                version=data["version"],
                mapping_json=data["mapping_json"],
                status=data["status"]
            )
            
            print(f"   Active mapping found: {mapping.mapping_id} (v{mapping.version})")
            self._active_mapping = mapping
            
            return mapping
            
        except requests.RequestException as e:
            raise NextReceiptException(f"Failed to fetch active mapping: {str(e)}")
    
    def _transform_json(self, original_json: Dict[str, Any], mapping_id: str, token: str) -> Dict[str, Any]:
        """
        Transform original JSON using mapping
        
        Args:
            original_json: Original provider JSON
            mapping_id: Mapping ID to use
            token: OAuth access token
            
        Returns:
            Transformed JSON in NextReceipt format
            
        Raises:
            TransformationException: If transformation fails
        """
        # The mapping expects the JSON structure WITHOUT the outer payload wrapper
        # So if original_json has a "payload" property, we send just that
        # Otherwise, we send the whole object
        json_to_transform = original_json
        
        # Extract payload content for transformation (without payload wrapper)
        try:
            if isinstance(original_json, dict) and "payload" in original_json:
                json_to_transform = original_json["payload"]
                print("   Extracted payload content for transformation (without payload wrapper)")
            else:
                print("   No payload wrapper found, using original JSON")
        except Exception as ex:
            print(f"   Could not extract payload: {ex}")
        
        # Debug: show what we're sending to transformation
        try:
            import json
            json_string = json.dumps(json_to_transform)
            print(f"   JSON being sent to transformation (first 500 chars): {json_string[:500]}...")
        except Exception as ex:
            print(f"   Could not serialize JSON for debug: {ex}")
        
        try:
            response = requests.post(
                f"{self.options.base_url}/api/transform/json",
                json={
                    "mapping_id": mapping_id,
                    "original_json": json_to_transform
                },
                timeout=self.options.timeout
            )
            
            if response.status_code != 200:
                raise TransformationException(
                    f"Transformation failed: {response.status_code} - {response.text}"
                )
            
            data = response.json()
            
            if not data.get("success"):
                errors = ", ".join(data.get("errors", ["Unknown error"]))
                raise TransformationException(f"Transformation failed: {errors}")
            
            transformed = data["transformed_json"]
            print("   JSON transformation successful")
            
            return transformed
            
        except requests.RequestException as e:
            raise TransformationException(f"Failed to transform JSON: {str(e)}")
    
    def _send_to_webhook(self, receipt_data: Dict[str, Any], token: str) -> ReceiptResponse:
        """
        Send receipt to webhook endpoint
        
        Args:
            receipt_data: Receipt data with 'payload' wrapper
            token: OAuth access token
            
        Returns:
            ReceiptResponse
        """
        try:
            response = requests.post(
                f"{self.options.base_url}/api/webhooks",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json"
                },
                json=receipt_data,
                timeout=self.options.timeout
            )
            
            data = response.json()
            
            if response.status_code == 200 and data is not None:
                result = ReceiptResponse.from_api_response(data)
                
                # Normalize response: if Ok is true, set Success to true for consistency
                if data.get("ok") and not result.success:
                    # Keep Success in sync with Ok, except for duplicate responses
                    if not result.duplicate:
                        result.success = True
                
                if result.duplicate:
                    print(f"   ⚠️  Duplicate receipt detected: {data.get('message')}")
                    # Ensure duplicate responses are not considered success in the sample app flow
                    result.success = False
                elif (data.get("ok") or result.success) and result.receipt_id:
                    print(f"   ✅ Receipt sent successfully! ID: {result.receipt_id}")
                else:
                    print(f"   ⚠️  Receipt processed but with warnings: {data.get('message')}")
                
                return result
            
            raise Exception(f"Failed to send receipt: {response.status_code} - {response.text}")
            
        except requests.RequestException as e:
            raise Exception(f"Failed to send receipt: {str(e)}")
    
    def get_active_mapping_info(self) -> Optional[MappingInfo]:
        """
        Get information about active mapping (if exists)
        
        Returns:
            MappingInfo or None if no active mapping
        """
        try:
            token = self._get_oauth_token()
            return self._get_active_mapping(token)
        except MappingNotFoundException:
            return None

