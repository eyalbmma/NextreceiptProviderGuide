"""
Custom exceptions for NextReceipt SDK
"""

class NextReceiptException(Exception):
    """Base exception for all NextReceipt SDK errors"""
    pass


class AuthenticationException(NextReceiptException):
    """Raised when OAuth authentication fails"""
    pass


class DuplicateReceiptException(NextReceiptException):
    """Raised when attempting to send a duplicate receipt (same sale.id)"""
    pass


class MappingNotFoundException(NextReceiptException):
    """Raised when no active mapping is found"""
    pass


class TransformationException(NextReceiptException):
    """Raised when JSON transformation fails"""
    pass


class ValidationException(NextReceiptException):
    """Raised when receipt validation fails"""
    pass

