"""
NextReceipt SDK for Python
Simplifies integration with NextReceipt API
"""

from .client import NextReceiptClient
from .models import ReceiptResponse, ClientOptions
from .exceptions import NextReceiptException, DuplicateReceiptException, AuthenticationException

__version__ = "1.1.0"
__all__ = [
    "NextReceiptClient",
    "ReceiptResponse", 
    "ClientOptions",
    "NextReceiptException",
    "DuplicateReceiptException",
    "AuthenticationException"
]

