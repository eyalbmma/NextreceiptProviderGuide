"""
Data models for NextReceipt SDK
"""

from typing import Optional, Any, Dict
from dataclasses import dataclass
from datetime import datetime


@dataclass
class ClientOptions:
    """Configuration options for NextReceiptClient"""
    base_url: str = "https://nextreceipt-api.onrender.com"
    timeout: int = 30
    auto_retry: bool = True
    max_retries: int = 3
    cache_token: bool = True
    throw_on_duplicate: bool = False
    enable_logging: bool = True


@dataclass
class ReceiptResponse:
    """Response from sending a receipt"""
    success: bool
    ok: bool = False
    receipt_id: Optional[str] = None
    token: Optional[str] = None
    qr_url: Optional[str] = None
    html_url: Optional[str] = None
    user_linked: bool = False
    push_notification_sent: bool = False
    duplicate: bool = False
    message: Optional[str] = None
    error: Optional[str] = None
    
    @property
    def is_success(self) -> bool:
        """Computed property that returns true if either Ok or Success is true"""
        return self.ok or self.success
    
    @classmethod
    def from_api_response(cls, response_data: Dict[str, Any]) -> 'ReceiptResponse':
        """Create ReceiptResponse from API response"""
        return cls(
            success=response_data.get("success", False),
            ok=response_data.get("ok", False),
            receipt_id=response_data.get("receipt_id"),
            token=response_data.get("token"),
            qr_url=response_data.get("qr_url"),
            html_url=response_data.get("html_url"),
            user_linked=response_data.get("user_linked", False),
            push_notification_sent=response_data.get("push_notification_sent", False),
            duplicate=response_data.get("duplicate", False),
            message=response_data.get("message"),
            error=response_data.get("detail") or response_data.get("error")
        )


@dataclass
class MappingInfo:
    """Information about active mapping"""
    mapping_id: str
    version: int
    mapping_json: Dict[str, Any]
    status: str
    created_at: Optional[datetime] = None
    activated_at: Optional[datetime] = None

